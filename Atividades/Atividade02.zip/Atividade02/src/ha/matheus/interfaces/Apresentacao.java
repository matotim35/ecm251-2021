package ha.matheus.interfaces;

public interface Apresentacao {
    public void apresentarMembros();
}
