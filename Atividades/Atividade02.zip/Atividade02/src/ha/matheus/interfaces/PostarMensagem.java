package ha.matheus.interfaces;

import ha.matheus.enums.SystemTime;

public interface PostarMensagem {
    public void postarMensagem(String mensagem, SystemTime time);
}
