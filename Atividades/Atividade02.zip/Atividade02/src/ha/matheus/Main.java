package ha.matheus;

import java.io.FileNotFoundException;

/**
 * Matheus Sungho Ha- 18.00525-0
 * verion 1.0
 *
 */


public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Menu.run();

    }
}
