package ha.matheus.enums;

public enum SystemTime {
    Regular, Extra;

}
