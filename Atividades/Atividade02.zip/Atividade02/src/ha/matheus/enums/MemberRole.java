package ha.matheus.enums;

public enum MemberRole {
    MobileMember, HeavyLifters, ScriptGuys, BigBrothers;
}
